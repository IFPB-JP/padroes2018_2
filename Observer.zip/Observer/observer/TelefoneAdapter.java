package observer;

public class TelefoneAdapter implements TelefoneListener {

	public void telefoneTocou(TelefoneEvent e) {}
	public void telefoneAtendido(TelefoneEvent e) {}
}
